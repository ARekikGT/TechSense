# chess > 2024-12-11 10:52pm
https://universe.roboflow.com/chess-coach-robot/chess-lchpu

Provided by a Roboflow user
License: CC BY 4.0

