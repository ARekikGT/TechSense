# chess > 2024-12-12 1:52pm
https://universe.roboflow.com/chess-coach-robot/chess-lchpu

Provided by a Roboflow user
License: CC BY 4.0

